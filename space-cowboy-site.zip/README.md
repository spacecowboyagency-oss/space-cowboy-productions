# Space Cowboy Productions — GitHub Pages Site

A lightweight, single-file portfolio to showcase AI video work.

## Quick Start

1. **Create a repo** named `space-cowboy-productions` (or any name).
2. Upload the files in this folder to the repo root:
   - `index.html`
   - `assets/style.css`
   - `assets/logo-placeholder.svg`
   - `assets/poster-placeholder.jpg` (optional, add your own)
   - `assets/hero-reel-placeholder.mp4` (optional, add your own)
   - `assets/sample.mp4` (replace with your MP4 or remove the third card)
3. Commit and push.

## Enable GitHub Pages
- Go to **Settings → Pages**.
- Set **Source** to `Deploy from a branch`.
- Choose `main` branch and `/ (root)`.
- Save; your site will publish at `https://<your-user>.github.io/<repo>/`.

## Connect Custom Domain
1. In **Settings → Pages**, add your domain `spacecowboyproductions.com`.
2. In your DNS (where the domain is managed), add these records:
   - For apex/root domain:
     - `A` → `185.199.108.153`
     - `A` → `185.199.109.153`
     - `A` → `185.199.110.153`
     - `A` → `185.199.111.153`
   - For `www`:
     - `CNAME` → `<your-user>.github.io`
3. Wait for DNS to propagate, then enable **Enforce HTTPS**.

## Swap Your Videos
In `index.html`, find the **Featured Work** section and replace:
- YouTube: change `src="https://www.youtube.com/embed/..."`
- Vimeo: change `src="https://player.vimeo.com/video/..."`
- MP4: replace `assets/sample.mp4` with your file and update poster image if desired.

## Tweak Styles
- Accent colors live in `assets/style.css` at the top (`--brand`, `--accent`).

## Optional
- Replace the placeholder logo file with your real logo at `assets/logo-placeholder.svg` (keep filename or update the `<img>` tag in `index.html`).
